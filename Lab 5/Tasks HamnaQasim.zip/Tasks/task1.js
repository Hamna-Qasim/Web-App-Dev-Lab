console.log(typeof 761313430n);
console.log(typeof Symbol("Symbol"));