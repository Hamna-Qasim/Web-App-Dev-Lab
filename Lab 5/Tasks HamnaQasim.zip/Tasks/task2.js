const Poster=
{
    name: "PAK WHEELS: WATERLESS & GLASS CLEANER",
    priceBefore: 1108,
    priceAfter: 958,
    Discount: "20%",
    Items:2,
}
console.log("Product Name: " + Poster.name);
console.log("Price Before Discount: " + Poster.priceBefore);
console.log("Price After Discount: " + Poster.priceAfter);
console.log("Discount: " + Poster.Discount);
console.log("Items: " + Poster.Items)
