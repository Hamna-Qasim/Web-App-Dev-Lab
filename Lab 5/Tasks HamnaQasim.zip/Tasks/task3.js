const Profile=
{
    username: "hamanqasim",
    profileName: "Hamna Qasim ",
    followers:108,
    following:137,
    posts: 23,
    higlights: 3,
    bio: "Though your beginnings may be humble, May the  end be prosperous",
}


console.log("Username: " + Profile.username);
console.log("Name: " + Profile.profileName);
console.log("Posts: " + Profile.posts);
console.log("Highlights: " + Profile.highlights);
console.log("Followers: " + Profile.followers);
console.log("Following: " + Profile.following);
console.log("Bio: " + Profile.bio);