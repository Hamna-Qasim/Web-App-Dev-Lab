let a=7;

console.log("a++ : "+ a++);
console.log("++a : " + (++a));
console.log("a-- : "+ a--);
console.log("--a : " + (--a));