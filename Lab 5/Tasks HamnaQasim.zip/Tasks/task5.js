let num=prompt("Enter a number: ");

if(num%3==0)
{
    console.log("This number is  a multiple of 3!");
}

else
{
    console.log("This number is not a multiple of 3!");
}
